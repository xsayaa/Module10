import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Ethical Past Dogfish</title>
        <meta property="og:title" content="Ethical Past Dogfish" />
      </Helmet>
      <h1>HELLO! :)</h1>
      <iframe
        src="https://www.youtube.com/embed/DeQkMK5LME4"
        className="home-iframe"
      ></iframe>
      <form className="home-form">
        <label>Did you enjoy it?</label>
      </form>
    </div>
  )
}

export default Home
